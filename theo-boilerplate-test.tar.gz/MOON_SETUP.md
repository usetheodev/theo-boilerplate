# Moon Setup - theo-boilerplate

Este guia explica como instalar e usar **Moon** (moonrepo.dev) para gerenciar builds no monorepo.

## 📦 Instalação

### 1. Instalar Proto (Version Manager)

**Proto** é o gerenciador de versões que o Moon usa para instalar ferramentas automaticamente.

#### Linux/macOS:
```bash
curl -fsSL https://moonrepo.dev/install/proto.sh | bash
```

#### Ou via Homebrew (macOS):
```bash
brew install moonrepo/tap/proto
```

### 2. Instalar Moon CLI

Após instalar Proto, instale Moon:

```bash
proto install moon
```

### 3. Verificar Instalação

```bash
moon --version  # Should output: moon X.Y.Z
proto --version # Should output: proto X.Y.Z
```

### 4. Instalar Node.js via Proto (Opcional)

Moon pode gerenciar a versão do Node.js automaticamente:

```bash
proto install node 20
```

---

## 🚀 Uso Básico

### Listar Projetos

```bash
moon query projects
```

**Output esperado:**
```
api
types
validators
web
```

### Visualizar Dependency Graph

```bash
moon query graph --dot | dot -Tpng > graph.png
```

### Executar Tasks

#### Build de um projeto específico:
```bash
moon run web:build     # Build apenas o frontend
moon run api:build     # Build apenas o backend
```

#### Build de todos os projetos:
```bash
moon run :build        # Build all projects in topological order
```

#### Executar dev servers:
```bash
moon run web:dev       # Vite dev server (port 3000)
moon run api:dev       # NestJS dev server (port 3001)
```

#### Executar em paralelo (múltiplos projetos):
```bash
moon run web:dev api:dev  # Run both dev servers
```

### Linting e Type-Checking

```bash
moon run :lint          # Lint all projects
moon run :type-check    # Type-check all projects
```

### Testing

```bash
moon run api:test       # Run API tests
moon run api:test:cov   # Run with coverage
moon run api:test:e2e   # Run E2E tests
```

---

## 🎯 Vantagens do Moon

### 1. Auto-Detection de Projetos
Moon descobre automaticamente projetos via `moon.yml`:
```bash
# Não precisa especificar paths hardcoded!
moon run web:build  # Funciona de qualquer lugar no monorepo
```

### 2. Smart Caching
Moon só rebuilda o que mudou:
```bash
moon run :build  # Primeira execução: 3-5 min
moon run :build  # Segunda execução: ~1s (tudo cached!)
```

### 3. Dependency Graph Automático
```bash
# Moon sabe que web depende de types e validators
moon run web:build  # Automatically builds types → validators → web
```

### 4. Paralelização Inteligente
```bash
# Moon executa tasks em paralelo quando possível
moon run :build
# types e validators em paralelo → depois web e api em paralelo
```

### 5. Multi-Language Nativo
```bash
# Futuro: adicionar projeto Python (FastAPI)
# Moon suporta Python nativamente (Tier 1)
```

---

## 📁 Estrutura de Configuração

```
theo-boilerplate/
├── .moon/
│   └── workspace.yml          # Workspace-level config
├── apps/
│   ├── web/
│   │   └── moon.yml           # Project config (Vite + React)
│   └── api/
│       └── moon.yml           # Project config (NestJS)
└── packages/
    ├── types/
    │   └── moon.yml           # Shared types
    └── validators/
        └── moon.yml           # Zod schemas
```

---

## 🔧 Comparação com Turbo

| Feature | Turborepo | Moon |
|---------|-----------|------|
| **Build speed** | Fast | Fast |
| **Cache** | Local + Remote | Local + Remote |
| **Multi-language** | JS/TS only | ✅ **JS/TS/Python/Go/Rust** |
| **Auto-detection** | ❌ Manual config | ✅ Auto via `moon.yml` |
| **Toolchain mgmt** | ❌ Manual | ✅ Proto (auto-download) |
| **Python support** | ❌ No | ✅ **Tier 1 native** |
| **Dependency graph** | Manual in turbo.json | ✅ **Auto-generated** |

---

## 🌐 Remote Caching (FASE 3)

Moon suporta remote caching via S3/Spaces:

```yaml
# .moon/workspace.yml (será configurado depois)
runner:
  cacheLifetime: '7 days'
  archiveableTargets:
    - 'build'
    - 'test'

# Environment variables (Kubernetes Secret)
MOON_REMOTE_CACHE_URL=s3://theo-moon-cache
AWS_ACCESS_KEY_ID=xxx
AWS_SECRET_ACCESS_KEY=xxx
```

**Benefício**: Builds ~10-30x mais rápidos com cache compartilhado entre CI e desenvolvedores.

---

## 📊 Comandos Úteis

### Ver cache status:
```bash
moon query touched-files  # Files changed since last commit
moon clean cache          # Clear local cache
```

### Debug task execution:
```bash
moon run web:build --log debug  # Verbose output
moon run web:build --log trace  # Maximum verbosity
```

### CI/CD Integration:
```bash
# Run all tasks affected by changes
moon run :build --affected

# Run in CI mode (stricter checks)
moon ci
```

---

## 🎓 Próximos Passos

1. ✅ **Instalação completa** (Proto + Moon)
2. ✅ **Validar builds localmente** (`moon run :build`)
3. 🔜 **Integrar nos Argo Workflows** (WorkflowTemplate)
4. 🔜 **Configurar remote caching** (S3 backend)
5. 🔜 **Adicionar Python stack** (futuro)

---

## 📚 Documentação Oficial

- Moon Docs: https://moonrepo.dev/docs
- Proto Docs: https://moonrepo.dev/docs/proto
- GitHub: https://github.com/moonrepo/moon

---

**Última atualização**: 2025-12-11
