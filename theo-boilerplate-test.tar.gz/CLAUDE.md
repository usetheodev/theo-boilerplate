# CLAUDE.md - theo-boilerplate

This file provides guidance to Claude Code when working with code in this repository.

---

## 🎯 Purpose

This is a **professional full-stack boilerplate** with enterprise-grade authentication and type-safety. It contains two applications:
- **apps/web**: Vite + React 18 frontend (TypeScript, SPA)
- **apps/api**: NestJS 10 backend (TypeScript)

This monorepo provides a production-ready foundation with complete auth system, optimized builds, and modern developer experience using **Moon** (moonrepo.dev).

---

## 🛠️ Commands

### Installation
```bash
# Install all dependencies (uses pnpm workspaces)
pnpm install

# Install Moon CLI (if not already installed)
./scripts/install-moon.sh
```

### Development
```bash
# Run all apps in dev mode (parallel via Moon)
pnpm dev              # or: moon run :dev

# Run specific app
moon run web:dev      # Vite on port 3000 (with HMR)
moon run api:dev      # NestJS on port 3001

# Or navigate to app directory
cd apps/web && pnpm dev
cd apps/api && pnpm dev
```

### Build
```bash
# Build all apps (uses Moon pipeline)
pnpm build            # or: moon run :build

# Build specific app
moon run web:build    # Build frontend only
moon run api:build    # Build backend only
```

### Linting & Type Checking
```bash
# Lint all apps
pnpm lint             # or: moon run :lint

# Type-check all apps
pnpm typecheck        # or: moon run :typecheck

# Lint specific app
moon run web:lint
moon run api:lint
```

### Testing
```bash
# Run API tests
moon run api:test

# Run with coverage
moon run api:test-cov

# Run E2E tests
moon run api:test-e2e
```

### Database (Prisma)
```bash
# Run migrations
pnpm db:migrate       # or: moon run api:prisma-migrate

# Open Prisma Studio
pnpm db:studio        # or: moon run api:prisma-studio

# Reset database
pnpm db:reset
```

---

## 🏗️ Architecture

### Monorepo Structure

```
theo-boilerplate/
├── .moon/
│   └── workspace.yml         # Moon workspace config
├── apps/
│   ├── web/                  # Vite + React (standalone output)
│   │   ├── moon.yml          # Project config
│   │   └── dist/             # Build output
│   └── api/                  # NestJS (compiled to dist/)
│       ├── moon.yml          # Project config
│       └── dist/             # Build output
├── packages/
│   ├── types/                # Shared TypeScript types
│   ├── validators/           # Zod validation schemas
│   ├── tsconfig/             # Shared tsconfig
│   └── eslint-config/        # Shared ESLint config
├── package.json              # Root workspace config
├── pnpm-workspace.yaml       # pnpm workspace definition
└── theo.yaml                 # THEO Platform config
```

### Apps Overview

**apps/web (Vite + React)**
- Framework: Vite 5 + React 18 (SPA)
- TypeScript: Yes (strict mode)
- Styling: Tailwind CSS 3.4
- Router: React Router 6
- State: Tanstack Query 5
- Output: Static files in `dist/` directory
- Build: Fast HMR, optimized production builds
- Config: `vite.config.ts`, `moon.yml`

**apps/api (NestJS)**
- Framework: NestJS 10
- TypeScript: Yes (strict mode)
- ORM: Prisma
- Output: Compiled to `dist/` directory
- Entry: `dist/main.js`
- Config: `nest-cli.json`, `moon.yml`

### Moon Task Runner

**Why Moon?**
- ✅ Auto-detection of projects via `moon.yml`
- ✅ Multi-language support (JS/TS/Python/Go/Rust)
- ✅ Intelligent dependency graph
- ✅ Smart caching (local + remote)
- ✅ Parallel execution
- ✅ Toolchain management via Proto

**Defined in `.moon/workspace.yml` and project `moon.yml` files**:
- **build**: Production builds with caching
- **dev**: Development servers (no cache, persistent)
- **lint**: ESLint checks (cached)
- **typecheck**: TypeScript type checking (cached)
- **test**: Jest tests (cached)

### Workspace Management

- **Package manager**: pnpm 8.15.0 (specified in `package.json`)
- **Task runner**: Moon 1.41.7 (installed via Proto)
- **Workspaces**: Defined in `pnpm-workspace.yaml`
  - `apps/*` - Applications
  - `packages/*` - Shared packages

---

## 🎯 Key Features

### Complete Authentication
- JWT tokens + Refresh tokens
- OAuth 2.0 (Google, GitHub)
- Email verification
- RBAC (Role-Based Access Control)
- Password reset flow

### Type-Safety End-to-End
- Shared types via `@repo/types`
- Zod validation via `@repo/validators`
- Prisma ORM with generated types
- TypeScript strict mode everywhere

### Modern Frontend
- Vite HMR (instant feedback)
- React 18 with concurrent features
- Tailwind CSS with dark mode support
- React Router 6 (type-safe routes)
- Tanstack Query (server state management)

### Enterprise Backend
- NestJS modular architecture
- Guards & Decorators
- Dependency Injection
- Swagger API documentation
- Health checks & Terminus

### Developer Experience
- Moon task runner (parallel builds, smart caching)
- pnpm workspaces (fast installs)
- ESLint + Prettier (code quality)
- Husky + lint-staged (pre-commit hooks)
- Commitlint (conventional commits)

---

## 🚀 Moon Benefits (vs Turborepo)

| Feature | Turborepo | Moon |
|---------|-----------|------|
| **Multi-language** | ❌ JS/TS only | ✅ JS/TS/Python/Go/Rust |
| **Auto-detection** | ❌ Manual config | ✅ Via moon.yml |
| **Dependency graph** | Manual in turbo.json | ✅ Auto-generated |
| **Toolchain mgmt** | ❌ Manual | ✅ Proto (auto-download) |
| **Python support** | ❌ No | ✅ **Tier 1 native** |
| **Local caching** | ✅ Yes | ✅ Yes |
| **Remote caching** | ✅ Yes | ✅ Yes (S3/Spaces) |

**Key advantage**: Moon is **future-proof** for adding Python (FastAPI) and other languages without refactoring.

---

## 🔑 Implementation Details

### Vite App (web)
- **SPA (Single Page Application)** - Client-side rendering only
- Port: 3000 (Vite dev server)
- Build output: `dist/` directory (static files)
- Deploy: Vercel, Netlify, nginx, DigitalOcean Spaces
- HMR: Instant hot module replacement

### NestJS App (api)
- Compiles TypeScript to `dist/` via `nest build`
- Port: 3000 (configurable via `PORT` environment variable)
- Start command: `node dist/main`
- Database: PostgreSQL via Prisma

### Moon Caching
- **Local cache**: `.moon/cache/` directory (gitignored)
- **Remote cache**: S3/Spaces (configured in FASE 3)
- **Cache keys**: Based on file hashes + dependencies
- **Cache hit rate**: 80-95% typical

---

## 📊 Performance Metrics

Development and build performance with Moon:

- **Moon query projects**: ~100ms (project discovery)
- **Vite dev server startup**: ~500ms (instant HMR)
- **NestJS dev server startup**: ~2-3s (with watch mode)
- **Frontend production build**: ~3s (moon run web:build)
- **Backend production build**: ~4s (moon run api:build)
- **Full monorepo build**: ~4s parallel (moon run :build)
- **Bundle size** (Vite):
  - Initial: ~245KB (gzipped: ~80KB)
  - With code splitting: ~50KB per route
- **Cache hit rate**: 80-95% (Moon local cache)

**Note**: Second builds with cache are near-instant (~1s).

---

## 🚨 Important Notes

1. **This is a boilerplate** - Production applications should customize security, auth flows, and business logic
2. **No Git repository** - This directory is part of the larger THEO Platform workspace
3. **Moon integration** - All builds and tasks use Moon (moonrepo.dev)
4. **Port conflicts** - Both apps default to port 3000; run separately or configure `PORT` env
5. **Future Python support** - Architecture ready for adding FastAPI apps (Moon native support)

---

## 📚 Documentation

- **Moon Setup**: `MOON_SETUP.md` - Complete guide to Moon installation and usage
- **FASE 1 Report**: `FASE1_COMPLETED.md` - Moon integration completion report
- **Platform docs**: `../docs/` - THEO Platform architecture

---

## 🔗 Related Links

- Moon Docs: https://moonrepo.dev/docs
- Proto Docs: https://moonrepo.dev/docs/proto
- Vite Docs: https://vitejs.dev
- NestJS Docs: https://nestjs.com
- Prisma Docs: https://prisma.io

---

**Last Updated**: 2025-12-11
**Build System**: Moon 1.41.7
**Package Manager**: pnpm 8.15.0
