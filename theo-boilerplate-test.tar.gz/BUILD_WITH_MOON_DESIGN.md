# 🏗️ Build-with-Moon WorkflowTemplate - Design Document

**Data**: 2025-12-11
**Versão**: 1.0.0
**Status**: Proposta de Design (Pronto para FASE 2)

---

## 📋 Sumário Executivo

Este documento descreve o design do `build-with-moon.yaml`, um Argo WorkflowTemplate que substitui os workflows hardcoded (`build-frontend.yaml`, `build-backend.yaml`) por uma solução flexível baseada em **Moon** (moonrepo.dev).

### Objetivos

✅ **Eliminar hardcoding** - Zero paths hardcoded (apps/web, apps/api)
✅ **Usar Moon como orquestrador** - Aproveitar dependency graph e caching
✅ **Multi-language ready** - Preparado para Python, Go, Rust (futuro)
✅ **Consistência dev-CI** - Mesmos comandos localmente e no CI
✅ **Preparado para remote cache** - S3/Spaces integration (FASE 3)

---

## 🎯 Decisão Arquitetural: Por que Moon como Orquestrador?

### Opções Avaliadas

| Opção | Pros | Contras | Decisão |
|-------|------|---------|---------|
| **A. Moon como Orquestrador** | ✅ Zero hardcoding<br>✅ Dependency graph<br>✅ Remote caching<br>✅ Multi-language | ⚠️ ~10s overhead instalação | ✅ **ESCOLHIDA** |
| B. Híbrido (Moon local, Argo direto) | ✅ Mais rápido | ❌ Inconsistência dev-CI<br>❌ Hardcoded paths | ❌ Rejeitada |
| C. Pack CLI (Container) | ✅ Zero overhead | ❌ Manter imagem custom<br>❌ Complexidade | ❌ Rejeitada |

### Justificativa da Escolha

**Razão 1: Alinhamento Estratégico**
- Moon foi escolhido **exatamente** para ser o build system unificado
- Não usá-lo no CI contradiz essa decisão
- Cria inconsistência entre desenvolvimento e produção

**Razão 2: Flexibilidade Total**
- Zero paths hardcoded → Estrutura de pastas pode mudar livremente
- Auto-discovery via `moon.yml` → Novos projetos aparecem automaticamente
- Multi-language → Adicionar FastAPI (Python) não requer mudar workflows

**Razão 3: Performance Futura (Remote Cache)**
- Na FASE 3, configuraremos S3/Spaces remote caching
- Moon gerencia cache automaticamente (95% cache hit rate possível)
- Builds futuros: ~1s (vs 4s atuais)

**Razão 4: Overhead Aceitável**
- Instalação do Moon: ~10s
- Build savings com cache: -50% tempo (FASE 3)
- **Trade-off vale a pena**: Flexibilidade + Performance > 10s overhead

---

## 🏗️ Arquitetura do Workflow

### Fluxo de Execução (DAG)

```
┌─────────────────────────────────────────────────────────────┐
│                    build-monorepo (DAG)                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. setup-workspace                                         │
│     ├─ Download source from S3 (artifact-path)             │
│     ├─ Extract tarball                                     │
│     ├─ Install Moon CLI (npm install -g @moonrepo/cli)     │
│     ├─ Install pnpm (corepack)                             │
│     ├─ pnpm install --frozen-lockfile                      │
│     └─ moon query projects (discovery)                     │
│                                                             │
│  2. moon-build (depends: setup)                             │
│     ├─ Parse projects parameter (e.g., "web,api")          │
│     ├─ FOR EACH project: moon run <project>:build &        │
│     └─ wait (parallel builds)                              │
│                                                             │
│  3. package-* (parallel, depends: moon-build)               │
│     ├─ package-web                                         │
│     │   ├─ tar apps/web/dist → web-<ingestion-id>.tar.gz   │
│     │   └─ aws s3 cp → s3://theo-build-artifacts/...       │
│     │                                                       │
│     └─ package-api                                         │
│         ├─ tar apps/api/dist → api-<ingestion-id>.tar.gz   │
│         └─ aws s3 cp → s3://theo-build-artifacts/...       │
│                                                             │
│  4. build-image-* (parallel, depends: package-*)            │
│     ├─ build-image-web (Kaniko)                            │
│     │   └─ Push to DO Registry: <app-id>-web:<ingestion>   │
│     │                                                       │
│     └─ build-image-api (Kaniko)                            │
│         └─ Push to DO Registry: <app-id>-api:<ingestion>   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Paralelização

- ✅ **Step 2**: Builds paralelos via `moon run web:build & moon run api:build & wait`
- ✅ **Step 3**: Package em paralelo (web e api simultâneos)
- ✅ **Step 4**: Docker builds em paralelo (web e api simultâneos)

**Tempo estimado**:
- Setup: ~15s (download + install deps)
- Build (parallel): ~4s (Moon builds web e api juntos)
- Package (parallel): ~3s
- Docker (parallel): ~30s
- **TOTAL: ~52s** (vs ~2min com workflows separados)

---

## 🔌 Integração com Sistema Atual

### Inputs (Parameters)

| Parameter | Exemplo | Descrição |
|-----------|---------|-----------|
| `ingestion-id` | `ing_1765466090098_zp5l2c` | UUID da ingestion (RFC 1123 safe) |
| `tenant-id` | `550e8400-e29b-41d4-a716-446655440000` | Tenant UUID |
| `app-id` | `7c9e6679-7425-40de-944b-e07fc1f90ae7` | Application UUID |
| `artifact-path` | `s3://theo-artifacts/tenants/...` | S3 path para source code |
| `projects` | `web,api` (default) | Projetos a buildar (ou "all") |
| `enable-remote-cache` | `false` (default) | Enable Moon remote cache (FASE 3) |

### Outputs

**S3 Artifacts**:
```
s3://theo-build-artifacts/
  └── <ingestion-id>/
      ├── web-<ingestion-id>.tar.gz   # Frontend build output
      └── api-<ingestion-id>.tar.gz   # Backend build output
```

**Docker Images**:
```
registry.digitalocean.com/theo-platform/
  ├── <app-id>-web:<ingestion-id>
  ├── <app-id>-web:latest
  ├── <app-id>-api:<ingestion-id>
  └── <app-id>-api:latest
```

### Integração com theo-builder-consumer

**Código atual** (`workflows.service.ts`):
```typescript
// ANTES (hardcoded)
const result = await this.submitWorkflow({
  templateName: projectType === 'frontend'
    ? 'build-frontend'   // ❌ Hardcoded
    : 'build-backend',   // ❌ Hardcoded
  // ...
});

// DEPOIS (Moon)
const result = await this.submitWorkflow({
  templateName: 'build-with-moon',  // ✅ Único template
  parameters: {
    'ingestion-id': ingestionId,
    'tenant-id': tenantId,
    'app-id': appId,
    'artifact-path': artifactPath,
    'projects': 'web,api',  // ✅ Flexível (ou detectar de theo.yaml)
  },
});
```

**Mudança necessária**: Update `workflows.service.ts` para usar `build-with-moon` (FASE 2).

---

## 📦 Estrutura do WorkflowTemplate

### Metadados

```yaml
apiVersion: argoproj.io/v1alpha1
kind: WorkflowTemplate
metadata:
  name: build-with-moon
  namespace: argo
  labels:
    theo.app/component: builder
    theo.app/workflow-type: monorepo-build
```

### Templates (4 principais)

#### 1. setup-workspace
- **Responsabilidade**: Preparar workspace para build
- **Container**: `node:20-alpine`
- **Recursos**: 512Mi RAM, 250m CPU
- **Outputs**: Workspace com código + deps instaladas

#### 2. moon-build
- **Responsabilidade**: Executar builds via Moon
- **Container**: `node:20-alpine`
- **Recursos**: 1Gi RAM, 500m CPU
- **Outputs**: `apps/web/dist/`, `apps/api/dist/`

#### 3. package-artifact
- **Responsabilidade**: Empacotar e upload para S3
- **Container**: `node:20-alpine` + AWS CLI
- **Recursos**: 256Mi RAM, 100m CPU
- **Outputs**: Tarball no S3

#### 4. build-docker-image
- **Responsabilidade**: Build e push Docker images
- **Container**: `gcr.io/kaniko-project/executor:v1.23.2`
- **Recursos**: 512Mi RAM, 250m CPU
- **Outputs**: Images no DO Registry

### Volumes

**VolumeClaimTemplate**:
```yaml
volumeClaimTemplates:
- metadata:
    name: workspace
  spec:
    accessModes: [ "ReadWriteOnce" ]
    resources:
      requests:
        storage: 10Gi  # Workspace compartilhado entre steps
```

**Secrets**:
- `theo-s3-credentials` - AWS access keys para S3
- `theo-docker-config` - Docker registry credentials (DO Registry)

---

## 🔐 Segurança e Permissões

### Kubernetes RBAC

**ServiceAccount**: `theo-builder-sa` (namespace: `builder`)

**Permissions necessárias** (já configuradas em FASE 3):
```yaml
# Role in argo namespace
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: workflow-executor
  namespace: argo
rules:
- apiGroups: ["argoproj.io"]
  resources: ["workflows"]
  verbs: ["create", "get", "list", "watch", "update", "patch"]

# RoleBinding (cross-namespace)
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: builder-can-submit-workflows
  namespace: argo
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: workflow-executor
subjects:
- kind: ServiceAccount
  name: theo-builder-sa
  namespace: builder  # ← Cross-namespace reference
```

### Secrets Management

**Criação dos Secrets** (executar manualmente):

```bash
# S3 credentials
kubectl create secret generic theo-s3-credentials \
  --from-literal=access-key-id="<AWS_KEY>" \
  --from-literal=secret-access-key="<AWS_SECRET>" \
  -n argo

# Docker registry
kubectl create secret docker-registry theo-docker-config \
  --docker-server=registry.digitalocean.com \
  --docker-username="<DO_TOKEN>" \
  --docker-password="<DO_TOKEN>" \
  -n argo
```

---

## 🚀 Deployment

### Onde colocar o arquivo?

**Repositório**: `theo-builder-gitops` (não theo-boilerplate!)

**Path**: `theo-builder-gitops/base/workflowtemplates/build-with-moon.yaml`

**Estrutura**:
```
theo-builder-gitops/
├── base/
│   ├── workflowtemplates/
│   │   ├── build-frontend.yaml      # ⚠️ DEPRECAR (FASE 2)
│   │   ├── build-backend.yaml       # ⚠️ DEPRECAR (FASE 2)
│   │   └── build-with-moon.yaml     # ✅ NOVO
│   └── kustomization.yaml           # ← Adicionar build-with-moon.yaml aqui
└── overlays/
    └── production/
        └── kustomization.yaml
```

### Aplicação via ArgoCD

**Step 1**: Commit `build-with-moon.yaml` ao repo
```bash
cd theo-builder-gitops
cp ../theo-boilerplate/build-with-moon.yaml base/workflowtemplates/
git add base/workflowtemplates/build-with-moon.yaml
git commit -m "feat: add build-with-moon WorkflowTemplate (FASE 2)"
git push
```

**Step 2**: Update `kustomization.yaml`
```yaml
# base/kustomization.yaml
resources:
- workflowtemplates/build-frontend.yaml    # ⚠️ Manter por enquanto
- workflowtemplates/build-backend.yaml     # ⚠️ Manter por enquanto
- workflowtemplates/build-with-moon.yaml   # ✅ Novo
```

**Step 3**: ArgoCD sync (automático ou manual)
```bash
# Manual sync (se necessário)
argocd app sync argo-workflows
argocd app wait argo-workflows
```

**Verificação**:
```bash
kubectl get workflowtemplate -n argo
# Esperado: build-frontend, build-backend, build-with-moon
```

---

## 🧪 Testing Strategy

### Teste Local (Simulado)

**Setup**: Use o theo-boilerplate como exemplo

```bash
cd theo-boilerplate

# Simular step 1: setup-workspace
pnpm install --frozen-lockfile
npm install -g @moonrepo/cli@1.41.7
moon --version

# Simular step 2: moon-build
moon run :build  # Deve buildar web e api em paralelo

# Verificar outputs
ls -lah apps/web/dist/
ls -lah apps/api/dist/

# Simular step 3: package-artifact
tar -czf web-test.tar.gz -C apps/web dist/
tar -czf api-test.tar.gz -C apps/api dist/
ls -lh *.tar.gz
```

**Resultado esperado**:
- ✅ Moon build completa (< 5s com cache)
- ✅ `apps/web/dist/` existe e tem `index.html`
- ✅ `apps/api/dist/` existe e tem `main.js`
- ✅ Tarballs criados (~245KB web, ~1MB api)

### Teste no Argo (E2E)

**Step 1**: Submit workflow manualmente
```bash
argo submit -n argo \
  --from workflowtemplate/build-with-moon \
  --parameter ingestion-id="test-$(date +%s)" \
  --parameter tenant-id="00000000-0000-0000-0000-000000000000" \
  --parameter app-id="test-app-id" \
  --parameter artifact-path="s3://theo-artifacts/test/source.tar.gz" \
  --parameter projects="web,api" \
  --parameter enable-remote-cache="false" \
  --watch
```

**Step 2**: Monitor execução
```bash
argo logs -n argo @latest -f
```

**Step 3**: Validar outputs

```bash
# Check S3 artifacts
aws s3 ls s3://theo-build-artifacts/test-*/

# Check Docker images
doctl registry repository list-tags theo-platform/test-app-id-web
doctl registry repository list-tags theo-platform/test-app-id-api
```

**Critérios de Sucesso**:
- ✅ Workflow completa com status `Succeeded`
- ✅ Todos os 6 steps (setup, build, 2x package, 2x docker) verdes
- ✅ Artifacts aparecem no S3
- ✅ Images aparecem no DO Registry
- ✅ Tempo total < 90s

---

## 🎯 Próximos Passos (FASE 2 Roadmap)

### Tarefas Pendentes

- [ ] **Deploy WorkflowTemplate**
  - Copiar `build-with-moon.yaml` para `theo-builder-gitops`
  - Update `kustomization.yaml`
  - Commit e push
  - ArgoCD sync

- [ ] **Update theo-builder-consumer**
  - Modificar `workflows.service.ts` para usar `build-with-moon`
  - Remover lógica de escolha entre `build-frontend` e `build-backend`
  - Adicionar parâmetro `projects` baseado em `theo.yaml`
  - Deploy novo código

- [ ] **Testing E2E**
  - Submeter workflow de teste (via CLI)
  - Submeter workflow via NATS event (theo-cli)
  - Validar artifacts no S3
  - Validar images no DO Registry

- [ ] **Cleanup Legacy Templates**
  - Deprecar `build-frontend.yaml`
  - Deprecar `build-backend.yaml`
  - Remover referências antigas

- [ ] **Documentação**
  - Update `docs/architecture/data-flow.md`
  - Update `theo-builder-consumer/README.md`
  - Criar runbook de troubleshooting

### FASE 3 (Futuro - Remote Cache)

- [ ] Deploy S3 bucket para Moon cache
- [ ] Configure `.moon/workspace.yml` com remote cache URL
- [ ] Update `build-with-moon.yaml` para passar credentials
- [ ] Testar cache hit rate (goal: 80-95%)

---

## 📊 Métricas de Sucesso

| Métrica | Baseline (Atual) | Target (Moon) | Status |
|---------|------------------|---------------|--------|
| **Build time** | ~60s (sequencial) | ~52s (parallel) | ⏳ Pendente |
| **Flexibilidade** | Hardcoded (2 apps) | Auto-discovery (∞ apps) | ✅ Design OK |
| **Cache hit rate** | 0% (sem cache) | 80-95% (FASE 3) | ⏳ FASE 3 |
| **Multi-language** | JS/TS only | JS/TS/Python/Go/Rust | ✅ Ready |
| **Consistência** | dev ≠ CI | dev = CI | ✅ Design OK |

---

## ❓ FAQ

### Q1: Por que não usar Cloud Native Buildpacks (pack CLI)?

**A**: Buildpacks são ótimos para aplicações simples, mas:
- ❌ Não suportam monorepos nativamente (precisam de buildpack customizado)
- ❌ Não aproveitam Moon dependency graph
- ❌ Menos flexível para multi-language
- ✅ Moon + Kaniko dá controle total e suporta qualquer estrutura

### Q2: Por que instalar Moon em cada execução? Não poderíamos usar uma imagem pre-baked?

**A**: Sim, poderíamos criar `theo-builder-base:latest` com Moon/pnpm pre-instalados. Vantagens:
- ✅ Economia de ~10s por build
- ✅ Versão consistente de Moon

Desvantagens:
- ❌ Mais uma imagem para manter
- ❌ Precisa rebuild quando Moon atualizar

**Decisão**: Começar com instalação on-demand, otimizar para imagem custom se overhead incomodar (FASE 3).

### Q3: Como adicionar suporte a Python (FastAPI) no futuro?

**A**: Apenas 2 passos:

1. Criar `apps/api-python/moon.yml`:
```yaml
id: 'api-python'
type: 'application'
language: 'python'
tasks:
  build:
    command: 'poetry build'
```

2. Update parâmetro no workflow submission:
```typescript
parameters: {
  'projects': 'web,api,api-python',  // ← Adicionar api-python
}
```

**Zero mudanças no WorkflowTemplate** - Moon auto-detecta Python e instala dependências.

### Q4: O que acontece se um build falhar?

**A**: Argo Workflows gerencia failures automaticamente:
- Step falha → Workflow status = `Failed`
- `WorkflowPollingService` detecta falha (FASE 3)
- Database atualizado: `BuildEventStatus.failed`
- Logs disponíveis: `kubectl logs -n argo workflow/<workflow-name>`

**Retry**: Pode resubmit workflow com mesmo `ingestion-id` (idempotente).

---

## 📚 Referências

- **Moon Docs**: https://moonrepo.dev/docs
- **Argo Workflows DAG**: https://argoproj.github.io/argo-workflows/walk-through/dag/
- **Kaniko**: https://github.com/GoogleContainerTools/kaniko
- **THEO Platform Docs**: `../docs/architecture/data-flow.md`

---

**Autor**: Claude Code
**Revisão**: Pendente
**Aprovação**: Pendente
**Status**: ✅ **Ready for Implementation (FASE 2)**
